# PoreAnalyser
PoreAnalyzer - automated rapid analysis and classification of defects in additive manufacturing processes, such as LPBF
